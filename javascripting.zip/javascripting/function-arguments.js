function math (x, y, z) {
    return(y*z+x)
    }
    
    console.log(math(53,61,67))