let total = 0
let limit = 10

for (let i = 0; i < 10; i++) {
total += i
}

console.log(total)