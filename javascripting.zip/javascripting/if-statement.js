let fruit = "orange"

x = fruit.length

if (x > 5) {
console.log("The fruit name has more than five characters.")
} else {
console.log("The fruit name has five characters or less.")
}