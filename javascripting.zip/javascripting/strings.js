const someString = 'this is a string'

console.log(someString)